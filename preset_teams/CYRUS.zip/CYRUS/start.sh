#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOST="localhost"
PLAYER_PORT="6000"
COACH_PORT=""
TEAM_NAME="Cyrus_Junior"

while (($# > 0)); do
    case "$1" in
        -h|--host)
            HOST="${2:?missing value for $1}"
            shift 2
            ;;
        -p|--port)
            PLAYER_PORT="${2:?missing value for $1}"
            shift 2
            ;;
        -P|--coach-port)
            COACH_PORT="${2:?missing value for $1}"
            shift 2
            ;;
        -t|--team-name)
            TEAM_NAME="${2:?missing value for $1}"
            shift 2
            ;;
        --help)
            printf 'Usage: %s [-h HOST] [-p PLAYER_PORT] [-P COACH_PORT] [-t TEAM_NAME]\n' "$0"
            exit 0
            ;;
        *)
            printf 'ERROR: unknown option: %s\n' "$1" >&2
            exit 2
            ;;
    esac
done

valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && ((10#$1 >= 1 && 10#$1 <= 65535))
}

if ! valid_port "$PLAYER_PORT"; then
    printf 'ERROR: invalid player port: %s\n' "$PLAYER_PORT" >&2
    exit 2
fi

if [[ -z "$COACH_PORT" ]]; then
    COACH_PORT="$((10#$PLAYER_PORT + 2))"
fi

if ! valid_port "$COACH_PORT"; then
    printf 'ERROR: invalid coach port: %s\n' "$COACH_PORT" >&2
    exit 2
fi

PLAYER="$SCRIPT_DIR/sample_player"
COACH="$SCRIPT_DIR/sample_coach"
PLAYER_CONFIG="$SCRIPT_DIR/player.conf"
COACH_CONFIG="$SCRIPT_DIR/coach.conf"
LOG_DIR="${CYRUS_LOG_DIR:-$SCRIPT_DIR/run-logs/port-$PLAYER_PORT}"
LAUNCH_DELAY="${CYRUS_LAUNCH_DELAY_SECONDS:-0.3}"
STARTUP_GRACE="${CYRUS_STARTUP_GRACE_SECONDS:-1}"

if [[ ! -x "$PLAYER" || ! -x "$COACH" ||
      ! -f "$PLAYER_CONFIG" || ! -f "$COACH_CONFIG" ||
      ! -e "$SCRIPT_DIR/lib/librcsc.so.18" ]]; then
    printf 'ERROR: Cyrus Junior team directory is incomplete: %s\n' "$SCRIPT_DIR" >&2
    exit 78
fi

mkdir -p -- "$LOG_DIR"
export LD_LIBRARY_PATH="$SCRIPT_DIR/lib:$SCRIPT_DIR${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

player_args=(
    --player-config "$PLAYER_CONFIG"
    --host "$HOST"
    --port "$PLAYER_PORT"
    --team_name "$TEAM_NAME"
)
coach_args=(
    --coach-config "$COACH_CONFIG"
    --host "$HOST"
    --port "$COACH_PORT"
    --team_name "$TEAM_NAME"
)

pids=()

cleanup_started_agents() {
    ((${#pids[@]} > 0)) || return 0
    kill "${pids[@]}" 2>/dev/null || true
    for pid in "${pids[@]}"; do
        wait "$pid" 2>/dev/null || true
    done
}

on_signal() {
    cleanup_started_agents
    exit 143
}

trap on_signal HUP INT TERM

"$PLAYER" "${player_args[@]}" --goalie >"$LOG_DIR/player-1.log" 2>&1 &
pids+=("$!")

for player_number in {2..11}; do
    sleep "$LAUNCH_DELAY"
    "$PLAYER" "${player_args[@]}" >"$LOG_DIR/player-${player_number}.log" 2>&1 &
    pids+=("$!")
done

sleep "$LAUNCH_DELAY"
"$COACH" "${coach_args[@]}" >"$LOG_DIR/coach.log" 2>&1 &
pids+=("$!")

sleep "$STARTUP_GRACE"
for pid in "${pids[@]}"; do
    if ! kill -0 "$pid" 2>/dev/null; then
        printf 'ERROR: Cyrus Junior agent exited during startup; logs: %s\n' "$LOG_DIR" >&2
        cleanup_started_agents
        exit 1
    fi
done

trap - HUP INT TERM
printf 'Cyrus Junior started: 11 players + 1 coach (player=%s, coach=%s; logs=%s)\n' \
    "$PLAYER_PORT" "$COACH_PORT" "$LOG_DIR"
