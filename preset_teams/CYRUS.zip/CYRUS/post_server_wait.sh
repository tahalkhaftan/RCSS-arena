#!/usr/bin/env bash
set -Eeuo pipefail

PLAYER_PROCESS="${PLAYER_PROCESS:-}"
COACH_PROCESS="${COACH_PROCESS:-}"
TEAM_PORT="${TEAM_PORT:-}"
POLL_SECONDS="${CYRUS_POST_SERVER_POLL_SECONDS:-1}"
TERM_GRACE_CHECKS="${CYRUS_POST_SERVER_TERM_GRACE_CHECKS:-5}"
PROC_NET_UDP="${CYRUS_PROC_NET_UDP_PATH:-/proc/net/udp}"
PROC_NET_UDP6="${CYRUS_PROC_NET_UDP6_PATH:-/proc/net/udp6}"

valid_process_name() {
    [[ "$1" =~ ^[A-Za-z0-9_.-]{1,15}$ ]]
}

if ! valid_process_name "$PLAYER_PROCESS" || ! valid_process_name "$COACH_PROCESS"; then
    printf 'ERROR: invalid Cyrus process name for post-server cleanup\n' >&2
    exit 2
fi

if ! [[ "$TEAM_PORT" =~ ^[0-9]+$ ]] ||
   ((10#$TEAM_PORT < 1 || 10#$TEAM_PORT > 65535)); then
    printf 'ERROR: invalid Cyrus server port: %s\n' "$TEAM_PORT" >&2
    exit 2
fi

if ! [[ "$POLL_SECONDS" =~ ^[0-9]+([.][0-9]+)?$ ]] ||
   ! awk -v value="$POLL_SECONDS" 'BEGIN { exit !(value > 0) }'; then
    printf 'ERROR: invalid Cyrus post-server poll interval: %s\n' "$POLL_SECONDS" >&2
    exit 2
fi

if ! [[ "$TERM_GRACE_CHECKS" =~ ^[0-9]+$ ]] ||
   ((10#$TERM_GRACE_CHECKS > 300)); then
    printf 'ERROR: invalid Cyrus TERM grace check count: %s\n' "$TERM_GRACE_CHECKS" >&2
    exit 2
fi

printf -v SERVER_PORT_HEX '%04X' "$((10#$TEAM_PORT))"

agents_alive() {
    pgrep -x -- "$PLAYER_PROCESS" >/dev/null ||
        pgrep -x -- "$COACH_PROCESS" >/dev/null
}

server_port_bound() {
    local paths=()
    [[ -r "$PROC_NET_UDP" ]] && paths+=("$PROC_NET_UDP")
    [[ -r "$PROC_NET_UDP6" ]] && paths+=("$PROC_NET_UDP6")
    ((${#paths[@]} > 0)) || return 1

    awk -v expected="$SERVER_PORT_HEX" '
        NR > 1 {
            split($2, local_address, ":")
            if (toupper(local_address[2]) == expected) found = 1
        }
        END { exit found ? 0 : 1 }
    ' "${paths[@]}" 2>/dev/null
}

terminate_leftovers() {
    local check
    printf 'Server UDP port %s disappeared; terminating leftover Cyrus agents\n' \
        "$TEAM_PORT"
    pkill -TERM -x -- "$PLAYER_PROCESS" 2>/dev/null || true
    pkill -TERM -x -- "$COACH_PROCESS" 2>/dev/null || true

    for ((check = 0; check < 10#$TERM_GRACE_CHECKS; ++check)); do
        agents_alive || return 0
        sleep "$POLL_SECONDS"
    done

    if agents_alive; then
        printf 'TERM grace expired; sending KILL to remaining Cyrus agents\n'
        pkill -KILL -x -- "$PLAYER_PROCESS" 2>/dev/null || true
        pkill -KILL -x -- "$COACH_PROCESS" 2>/dev/null || true
    fi
}

server_observed=0
while agents_alive; do
    if server_port_bound; then
        if ((server_observed == 0)); then
            printf 'Observed RoboCup server UDP port %s; post-server cleanup armed\n' \
                "$TEAM_PORT"
            server_observed=1
        fi
    elif ((server_observed == 1)); then
        terminate_leftovers
        exit 0
    fi
    sleep "$POLL_SECONDS"
done

exit 0
